<?php

$db_server = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "buisnessdb";
$conn = "";


$conn = mysqli_connect($db_server,
$db_user,$db_password,$db_name );


if($conn){
    echo"you are connected";

}
else{
    echo"you arre not connected";
}
?>
<?php
// Step 1: Database connection
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "restaurant_db";  // You can change this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Get the form data from POST request
$email = $_POST['email'];
$password = $_POST['password'];

// Step 3: Check if the email and password are correct
$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";  // Don't store passwords in plain text in real applications
$result = $conn->query($sql);

// Step 4: Check if a matching user is found
if ($result->num_rows > 0) {
    // Success: Redirect to another page or show a success message
    echo "Login successful!";
} else {
    // Failure: Display an error message
    echo "Invalid email or password.";
}

$conn->close();
?>
